1. Clone it to local machine and open this repo.
2. Open terminal and paste this command
    
    npm install

3.  Add paste the open ai and google maps api keys in the .env file

4. to start the backend paste this into the terminal


   node ceta.js

5. to see frontend type this in browser

    http://localhost:3000/

Youtube video : https://youtu.be/sa58KAoIzAw?feature=shared
